// src/components/admin/StoresManager.tsx
import { useEffect, useState, useCallback } from 'react';
import { Plus, Pencil, Trash2, X, Loader2, Save, ImageIcon, Search } from 'lucide-react';
import type { Store, FeatureItem, PremiumBadge } from '@/types';
import {
  fetchAllStores,
  createStore,
  updateStore,
  deleteStore,
  uploadStoreBannerImage,
  deleteStoreBannerImage,
} from '@/services/catalog';
import { iconNames } from '@/data/storeIcons';
import { Toast, ToastContainer } from '@/components/ui/Toast';
import { ConfirmationDialog } from '@/components/ui/ConfirmationDialog';
import { UploadProgress } from '@/components/ui/UploadProgress';
import { compressImage } from '@/lib/imageUtils';

export default function StoresManager() {
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'form'>('list');
  const [editingStore, setEditingStore] = useState<Store | null>(null);
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'error' | 'warning' | 'info' }>>([]);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    storeId?: string;
    title: string;
    message: string;
  }>({
    isOpen: false,
    title: '',
    message: '',
  });
  // Search state
  const [searchQuery, setSearchQuery] = useState('');

  const addToast = (message: string, type: 'success' | 'error' | 'warning' | 'info') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000);
  };

  const load = useCallback(async () => {
    try {
      const data = await fetchAllStores();
      setStores(data);
    } catch {
      addToast('Failed to load stores', 'error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const handleDeleteClick = (id: string) => {
    setConfirmDialog({
      isOpen: true,
      storeId: id,
      title: 'Delete Store',
      message: 'Are you sure you want to delete this store? This action cannot be undone.',
    });
  };

  const handleConfirmDelete = async () => {
    if (!confirmDialog.storeId) return;
    try {
      await deleteStore(confirmDialog.storeId);
      addToast('Store deleted successfully', 'success');
      await load();
    } catch {
      addToast('Failed to delete store', 'error');
    } finally {
      setConfirmDialog({ isOpen: false, storeId: undefined, title: '', message: '' });
    }
  };

  const handleToggle = async (store: Store) => {
    try {
      await updateStore(store.id, { is_active: !store.is_active });
      addToast(`Store ${!store.is_active ? 'activated' : 'deactivated'}`, 'success');
      await load();
    } catch {
      addToast('Failed to update store', 'error');
    }
  };

  const handleEdit = (store: Store) => {
    setEditingStore(store);
    setViewMode('form');
  };

  const handleAddNew = () => {
    setEditingStore(null);
    setViewMode('form');
  };

  const handleFormClose = () => {
    setViewMode('list');
    setEditingStore(null);
  };

  const handleFormSaved = () => {
    void load();
    setViewMode('list');
    addToast('Store saved successfully', 'success');
  };

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return <Loader2 className="animate-spin mx-auto text-brand-600" size={24} />;
  }

  if (viewMode === 'form') {
    return (
      <StoreForm
        initial={editingStore}
        onClose={handleFormClose}
        onSaved={handleFormSaved}
        addToast={addToast}
      />
    );
  }

  return (
    <div className="space-y-3">
      <ToastContainer>
        {toasts.map((t) => (
          <Toast key={t.id} message={t.message} type={t.type} onClose={() => setToasts((prev) => prev.filter((toast) => toast.id !== t.id))} />
        ))}
      </ToastContainer>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" size={16} />
        <input
          type="text"
          placeholder="Search stores..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-10 rounded-xl border border-ink-200 pl-9 pr-3 text-sm outline-none focus:border-brand-500"
        />
      </div>

      <button
        onClick={handleAddNew}
        className="w-full h-12 rounded-xl bg-brand-600 text-white text-sm font-bold flex items-center justify-center gap-2"
      >
        <Plus size={16} /> Add store
      </button>

      {filteredStores.map((store) => (
        <div key={store.id} className="bg-white border border-ink-100 rounded-2xl p-4 shadow-card">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3">
                {store.banner_image_url && (
                  <img src={store.banner_image_url} alt="" className="h-12 w-12 rounded-xl object-cover" />
                )}
                <div>
                  <p className="text-sm font-bold text-ink-800 truncate">{store.name}</p>
                  <p className="text-xs text-ink-500 truncate">{store.description}</p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span
                  className={`text-[10px] font-bold rounded-full px-2.5 py-0.5 ${
                    store.is_active ? 'bg-brand-100 text-brand-700' : 'bg-ink-100 text-ink-500'
                  }`}
                >
                  {store.is_active ? 'ACTIVE' : 'HIDDEN'}
                </span>
                <span className="text-[10px] text-ink-400 bg-ink-50 px-2 py-0.5 rounded-full">
                  Order: {store.sort_order}
                </span>
                <span className="text-[10px] text-ink-400 bg-ink-50 px-2 py-0.5 rounded-full">
                  Rating: {store.rating || '4.8'}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => void handleToggle(store)}
                className={`h-9 px-3 rounded-xl text-xs font-bold ${
                  store.is_active ? 'bg-brand-100 text-brand-700' : 'bg-ink-100 text-ink-500'
                }`}
              >
                {store.is_active ? 'ON' : 'OFF'}
              </button>
              <button
                onClick={() => handleEdit(store)}
                className="h-9 w-9 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center"
              >
                <Pencil size={14} />
              </button>
              <button
                onClick={() => handleDeleteClick(store.id)}
                className="h-9 w-9 rounded-xl bg-red-50 text-red-500 flex items-center justify-center"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        </div>
      ))}

      <ConfirmationDialog
        isOpen={confirmDialog.isOpen}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={handleConfirmDelete}
        onCancel={() => setConfirmDialog({ isOpen: false, storeId: undefined, title: '', message: '' })}
      />
    </div>
  );
}

// ---- StoreForm ----
function StoreForm({
  initial,
  onClose,
  onSaved,
  addToast,
}: {
  initial: Store | null;
  onClose: () => void;
  onSaved: () => void;
  addToast: (message: string, type: 'success' | 'error' | 'warning' | 'info') => void;
}) {
  const defaultFeatures: FeatureItem[] = [
    { icon: 'ShieldCheck', title: 'Hygienic', subtitle: 'Packing' },
    { icon: 'Leaf', title: 'Fresh &', subtitle: 'Quality' },
    { icon: 'Clock3', title: 'On Time', subtitle: 'Delivery' },
  ];

  const defaultPremium: PremiumBadge = {
    icon: 'Sparkles',
    label: 'PREMIUM',
    sublabel: 'QUALITY',
  };

  const [form, setForm] = useState({
    name: initial?.name ?? '',
    banner_image_url: initial?.banner_image_url ?? '',
    description: initial?.description ?? '',
    brand_color: initial?.primary_color ?? '#10b981',
    text_color: initial?.text_color ?? '#ffffff',
    sort_order: initial?.sort_order ?? 0,
    is_active: initial?.is_active ?? true,
    rating: initial?.rating ?? '4.8',
    orders: initial?.orders ?? '120+ Orders',
    store_icon: initial?.store_icon ?? 'Store',
    features: initial?.features?.length ? initial.features : defaultFeatures,
    premium_badge: initial?.premium_badge ?? defaultPremium,
    badge_text: initial?.badge_text ?? 'STORE',
    badge_color: initial?.badge_color ?? '#fbbf24',
  });

  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>(initial?.banner_image_url ?? '');
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(initial?.banner_image_url ?? null);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleFeatureChange = (index: number, field: keyof FeatureItem, value: string) => {
    const updated = [...form.features];
    updated[index] = { ...updated[index], [field]: value };
    setForm({ ...form, features: updated });
  };

  const handlePremiumChange = (field: keyof PremiumBadge, value: string) => {
    setForm({ ...form, premium_badge: { ...form.premium_badge, [field]: value } });
  };

  const handleSave = async () => {
    if (!form.name) {
      addToast('Store name is required', 'warning');
      return;
    }
    if (!form.banner_image_url && !selectedFile) {
      addToast('Please upload a store image', 'warning');
      return;
    }

    setSaving(true);
    let newImageUrl = form.banner_image_url;

    try {
      if (selectedFile) {
        setUploading(true);
        setUploadProgress(0);
        setUploadStatus('Compressing image...');

        const compressionSteps = 8;
        for (let i = 0; i <= compressionSteps; i++) {
          const progress = Math.min(30, (i / compressionSteps) * 30);
          setUploadProgress(progress);
          setUploadStatus(`Compressing... ${Math.round(progress)}%`);
          await new Promise((resolve) => setTimeout(resolve, 120));
        }

        const compressed = await compressImage(selectedFile);
        setUploadStatus('Compression complete. Uploading...');
        setUploadProgress(30);

        const uploadProgressCallback = (uploadPercent: number) => {
          const overall = 30 + (uploadPercent * 0.7);
          setUploadProgress(Math.min(100, overall));
          setUploadStatus(`Uploading... ${Math.round(overall)}%`);
        };

        newImageUrl = await uploadStoreBannerImage(compressed, uploadProgressCallback);

        setUploadProgress(100);
        setUploadStatus('Upload complete!');
      }

      // === FIX: Delete old image if the URL changed, regardless of how ===
      if (originalImageUrl && originalImageUrl !== newImageUrl) {
        await deleteStoreBannerImage(originalImageUrl);
      }

      const data = {
        name: form.name,
        image_url: newImageUrl,
        banner_image_url: newImageUrl,
        description: form.description,
        primary_color: form.brand_color,
        text_color: form.text_color,
        sort_order: form.sort_order,
        is_active: form.is_active,
        rating: form.rating,
        orders: form.orders,
        store_icon: form.store_icon,
        features: form.features,
        premium_badge: form.premium_badge,
        badge_text: form.badge_text,
        badge_color: form.badge_color,
        config: initial?.config || {},
      };

      if (initial) {
        await updateStore(initial.id, data);
      } else {
        await createStore(data);
      }

      onSaved();
    } catch (err) {
      console.error(err);
      addToast('Failed to save store. Check console.', 'error');
    } finally {
      setSaving(false);
      setUploading(false);
      setUploadProgress(0);
      setUploadStatus('');
    }
  };

  if (uploading) {
    return (
      <UploadProgress
        progress={uploadProgress}
        statusText={uploadStatus}
        isComplete={uploadProgress >= 100}
      />
    );
  }

  return (
    <div className="bg-white border border-brand-200 rounded-2xl p-4 space-y-4 shadow-card">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-ink-900">{initial ? 'Edit' : 'New'} store</h3>
        <button onClick={onClose} className="h-10 w-10 flex items-center justify-center">
          <X size={16} className="text-ink-400" />
        </button>
      </div>

      {/* Store Image */}
      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Store Image *</label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            value={form.banner_image_url}
            onChange={(e) => {
              setForm({ ...form, banner_image_url: e.target.value });
              setPreviewUrl(e.target.value);
            }}
            placeholder="Image URL or upload"
            className="flex-1 h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
          />
          <label className="h-10 px-3 rounded-xl bg-brand-50 text-brand-600 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer">
            <ImageIcon size={14} /> Upload
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFileSelect(f);
              }}
            />
          </label>
        </div>
        {previewUrl && (
          <div className="relative mt-2">
            <img src={previewUrl} alt="Preview" className="h-20 w-full rounded-xl object-cover" />
            {selectedFile && (
              <span className="absolute top-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full">
                New
              </span>
            )}
          </div>
        )}
      </div>


      {/* Basic fields */}
      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Store name *</label>
        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="e.g. Fresh Harvest"
          className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
        />
      </div>

      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Description</label>
        <input
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="e.g. Farm-fresh staples"
          className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
        />
      </div>

      {/* Colors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Brand Color</label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={form.brand_color}
              onChange={(e) => setForm({ ...form, brand_color: e.target.value })}
              className="h-10 w-16 rounded-xl border border-ink-200 p-1"
            />
            <input
              type="text"
              value={form.brand_color}
              onChange={(e) => setForm({ ...form, brand_color: e.target.value })}
              className="flex-1 h-10 rounded-xl border border-ink-200 px-3 text-sm font-mono outline-none focus:border-brand-500"
              placeholder="#000000"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Text Color</label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={form.text_color}
              onChange={(e) => setForm({ ...form, text_color: e.target.value })}
              className="h-10 w-16 rounded-xl border border-ink-200 p-1"
            />
            <input
              type="text"
              value={form.text_color}
              onChange={(e) => setForm({ ...form, text_color: e.target.value })}
              className="flex-1 h-10 rounded-xl border border-ink-200 px-3 text-sm font-mono outline-none focus:border-brand-500"
              placeholder="#ffffff"
            />
          </div>
        </div>
      </div>

      {/* Badge fields */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Badge Text</label>
          <input
            value={form.badge_text}
            onChange={(e) => setForm({ ...form, badge_text: e.target.value })}
            placeholder="STORE"
            className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Badge Color</label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={form.badge_color}
              onChange={(e) => setForm({ ...form, badge_color: e.target.value })}
              className="h-10 w-16 rounded-xl border border-ink-200 p-1"
            />
            <input
              type="text"
              value={form.badge_color}
              onChange={(e) => setForm({ ...form, badge_color: e.target.value })}
              className="flex-1 h-10 rounded-xl border border-ink-200 px-3 text-sm font-mono outline-none focus:border-brand-500"
              placeholder="#fbbf24"
            />
          </div>
        </div>
      </div>

      {/* Rating & Orders */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Rating</label>
          <input
            type="text"
            value={form.rating}
            onChange={(e) => setForm({ ...form, rating: e.target.value })}
            placeholder="4.8"
            className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Orders</label>
          <input
            type="text"
            value={form.orders}
            onChange={(e) => setForm({ ...form, orders: e.target.value })}
            placeholder="120+ Orders"
            className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
          />
        </div>
      </div>

      {/* Store Icon */}
      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Store Icon</label>
        <select
          value={form.store_icon}
          onChange={(e) => setForm({ ...form, store_icon: e.target.value })}
          className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
        >
          {iconNames.map((name) => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>
      </div>

      {/* Features */}
      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Features (max 3)</label>
        {form.features.map((feature, idx) => (
          <div key={idx} className="grid grid-cols-4 gap-2 mb-2">
            <select
              value={feature.icon}
              onChange={(e) => handleFeatureChange(idx, 'icon', e.target.value)}
              className="col-span-1 h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
            >
              {iconNames.map((name) => (
                <option key={name} value={name}>{name}</option>
              ))}
            </select>
            <input
              type="text"
              value={feature.title}
              onChange={(e) => handleFeatureChange(idx, 'title', e.target.value)}
              placeholder="Title"
              className="col-span-1 h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
            />
            <input
              type="text"
              value={feature.subtitle}
              onChange={(e) => handleFeatureChange(idx, 'subtitle', e.target.value)}
              placeholder="Subtitle"
              className="col-span-2 h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
            />
          </div>
        ))}
        {form.features.length < 3 && (
          <button
            onClick={() =>
              setForm({
                ...form,
                features: [...form.features, { icon: 'Package', title: 'New', subtitle: 'Feature' }],
              })
            }
            className="text-sm text-brand-600 font-medium"
          >
            + Add feature
          </button>
        )}
      </div>

      {/* Premium Badge */}
      <div>
        <label className="block text-xs font-bold text-ink-600 mb-1">Premium Badge</label>
        <div className="grid grid-cols-3 gap-2">
          <select
            value={form.premium_badge.icon}
            onChange={(e) => handlePremiumChange('icon', e.target.value)}
            className="h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
          >
            {iconNames.map((name) => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
          <input
            type="text"
            value={form.premium_badge.label}
            onChange={(e) => handlePremiumChange('label', e.target.value)}
            placeholder="Label"
            className="h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
          />
          <input
            type="text"
            value={form.premium_badge.sublabel}
            onChange={(e) => handlePremiumChange('sublabel', e.target.value)}
            placeholder="Sublabel"
            className="h-10 rounded-xl border border-ink-200 px-2 text-sm outline-none focus:border-brand-500"
          />
        </div>
      </div>

      {/* Sort order & Active */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold text-ink-600 mb-1">Sort order</label>
          <input
            type="number"
            value={form.sort_order}
            onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })}
            className="w-full h-10 rounded-xl border border-ink-200 px-3 text-sm outline-none focus:border-brand-500"
          />
        </div>
        <div className="flex items-end h-10">
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
              className="accent-brand-600"
            />{' '}
            Active
          </label>
        </div>
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="w-full h-11 rounded-xl bg-brand-600 text-white text-sm font-bold flex items-center justify-center gap-2"
      >
        {saving ? <Loader2 size={16} className="animate-spin" /> : <><Save size={16} /> Save store</>}
      </button>
    </div>
  );
}