import { useEffect, useState, useCallback } from 'react';
import {
  ArrowLeft,
  MapPin,
  Package,
  Truck,
  CheckCircle2,
  Clock,
  XCircle,
  Printer,
  Loader2,
  Wallet,
  CreditCard,
  Banknote,
  AlertCircle,
  AlertOctagon,
} from 'lucide-react';
import { fetchOrderDetail } from '@/services/catalog';
import type { DbOrder, DbOrderItem, DbAddress } from '@/services/catalog';
import { buildGstBillHtml } from '@/services/gstBill';
import { printHtml } from '@/utils/printHtml';
import { supabase } from '@/lib/supabase';

interface OrderDetailScreenProps {
  orderId: string;
  onBack: () => void;
}

interface OrderPaymentSummary {
  walletPaid: number;
  onlinePaid: number;
  codPaid: number;
  totalPaid: number;
  amountToCollect: number;
  isFullyPaid: boolean;
}

// Support cancel_reason on DbOrder
type OrderWithCancelReason = DbOrder & {
  cancel_reason?: string | null;
};

export function OrderDetailScreen({ orderId, onBack }: OrderDetailScreenProps) {
  const [order, setOrder] = useState<OrderWithCancelReason | null>(null);
  const [items, setItems] = useState<DbOrderItem[]>([]);
  const [address, setAddress] = useState<DbAddress | null>(null);
  const [paymentSummary, setPaymentSummary] = useState<OrderPaymentSummary>({
    walletPaid: 0,
    onlinePaid: 0,
    codPaid: 0,
    totalPaid: 0,
    amountToCollect: 0,
    isFullyPaid: false,
  });
  const [loading, setLoading] = useState(true);
  const [isPrinting, setIsPrinting] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [orderData, paymentsRes] = await Promise.all([
        fetchOrderDetail(orderId),
        supabase.from('payments').select('*').eq('order_id', orderId),
      ]);

      if (orderData) {
        setOrder(orderData.order as OrderWithCancelReason);
        setItems(orderData.items);
        setAddress(orderData.address);

        let walletPaid = 0;
        let onlinePaid = 0;
        let codPaid = 0;

        (paymentsRes.data || []).forEach((p) => {
          const pStatus = (p.status || '').toLowerCase();
          const pProvider = (p.provider || '').toLowerCase();
          const amt = Number(p.amount) || 0;

          if (pStatus === 'paid' || pStatus === 'completed') {
            if (pProvider === 'wallet') walletPaid += amt;
            else if (pProvider === 'razorpay') onlinePaid += amt;
            else if (pProvider === 'cod') codPaid += amt;
          }
        });

        const total = Number(orderData.order.total) || 0;
        const totalPaid = walletPaid + onlinePaid + codPaid;
        const pending = Math.max(0, total - totalPaid);
        const isDelivered = orderData.order.status === 'delivered';

        setPaymentSummary({
          walletPaid,
          onlinePaid,
          codPaid,
          totalPaid,
          amountToCollect: isDelivered ? 0 : pending,
          isFullyPaid: isDelivered || pending <= 0.01,
        });
      }
    } catch (err) {
      console.error('Failed to load order details:', err);
    } finally {
      setLoading(false);
    }
  }, [orderId]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="h-8 w-8 rounded-full border-2 border-brand-200 border-t-brand-600 animate-spin" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
        <p className="text-sm text-ink-500">Order not found</p>
        <button onClick={onBack} className="mt-3 text-sm font-bold text-brand-600">
          Go back
        </button>
      </div>
    );
  }

  const handlePrint = async () => {
    try {
      setIsPrinting(true);
      const html = await buildGstBillHtml(order.id);
      await printHtml(html, order.order_number || `Invoice_${order.id.slice(0, 8)}`);
    } catch (err) {
      console.error('Print Error:', err);
      alert('Failed to generate bill.');
    } finally {
      setIsPrinting(false);
    }
  };

  const statusSteps = [
    { key: 'pending', label: 'Order placed', icon: Clock },
    { key: 'confirmed', label: 'Confirmed', icon: Package },
    { key: 'packed', label: 'Packed', icon: Package },
    { key: 'ready_for_pickup', label: 'Ready for pickup', icon: Package },
    { key: 'out_for_delivery', label: 'Out for delivery', icon: Truck },
    { key: 'delivered', label: 'Delivered', icon: CheckCircle2 },
  ];

  const currentStepIndex =
    order.status === 'cancelled'
      ? -1
      : statusSteps.findIndex((s) => s.key === order.status);

  const normalizedStatus = order.status?.trim().toLowerCase();
  const canPrintBill = normalizedStatus === 'delivered' || normalizedStatus === 'confirmed';

  return (
    <div className="safe-top px-4 pb-6 space-y-4 max-w-lg mx-auto">
      <div className="flex items-center gap-3">
        <button
          onClick={onBack}
          className="h-9 w-9 rounded-xl bg-white border border-ink-200 flex items-center justify-center shadow-xs active:scale-95 transition-transform"
        >
          <ArrowLeft size={18} />
        </button>
        <div>
          <h1 className="text-lg font-extrabold text-ink-900 tracking-tight">
            {order.order_number}
          </h1>
          <p className="text-xs text-ink-500 mt-0.5">
            {new Date(order.created_at).toLocaleDateString('en-IN', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            })}
          </p>
        </div>
      </div>

      {/* Cancellation Reason Display Card */}
      {order.status === 'cancelled' ? (
        <div className="rounded-2xl bg-red-50 border border-red-200/80 p-4 space-y-2.5 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0 mt-0.5 border border-red-200">
              <XCircle size={20} strokeWidth={2.5} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-black text-red-800">Order Cancelled</p>
                <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-200/70 text-red-800">
                  Void
                </span>
              </div>
              <p className="text-xs text-red-600 mt-0.5">
                This order was cancelled and will not be delivered.
              </p>
            </div>
          </div>

          {/* Cancellation Reason Tag */}
          <div className="bg-white/80 rounded-xl p-3 border border-red-200/70 flex items-start gap-2">
            <AlertOctagon size={16} className="text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase font-black tracking-wider text-red-500">
                Cancellation Reason
              </p>
              <p className="text-xs font-bold text-red-950 mt-0.5 break-words">
                {order.cancel_reason?.trim() || 'Cancelled by warehouse manager'}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <section className="bg-white border border-ink-100 rounded-2xl p-4 shadow-card">
          <h2 className="text-sm font-bold text-ink-900 mb-3">Order status</h2>
          <div className="space-y-3">
            {statusSteps.map((step, index) => {
              const isDone = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;
              const Icon = step.icon;
              return (
                <div key={step.key} className="flex items-center gap-3">
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
                      isDone ? 'bg-brand-600 text-white' : 'bg-ink-100 text-ink-400'
                    }`}
                  >
                    <Icon size={15} />
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-bold ${isDone ? 'text-ink-800' : 'text-ink-400'}`}>
                      {step.label}
                    </p>
                    {isCurrent && <p className="text-[10px] text-brand-600 mt-0.5">Current status</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Payment Status Summary */}
      <section
        className={`rounded-2xl p-4 border shadow-xs ${
          paymentSummary.isFullyPaid
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
            : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {paymentSummary.isFullyPaid ? (
              <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle size={18} className="text-amber-600 shrink-0" />
            )}
            <div>
              <p className="text-xs font-bold uppercase tracking-wider">
                {paymentSummary.isFullyPaid ? 'Payment Complete' : 'Cash to Pay on Delivery'}
              </p>
              <p className="text-[11px] opacity-80 mt-0.5">
                {paymentSummary.isFullyPaid
                  ? 'All dues settled for this order'
                  : 'Pay remaining balance upon receiving delivery'}
              </p>
            </div>
          </div>
          <p className="text-base font-black">
            {paymentSummary.isFullyPaid
              ? '₹0.00'
              : `₹${paymentSummary.amountToCollect.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`}
          </p>
        </div>
      </section>

      {/* Items Section */}
      <section className="bg-white border border-ink-100 rounded-2xl p-4 shadow-card">
        <h2 className="text-sm font-bold text-ink-900 mb-3">Items ({items.length})</h2>
        <div className="space-y-3">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between items-start gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-ink-800">
                  {item.brand} {item.product_name}
                </p>
                <p className="text-xs text-ink-400 mt-0.5">
                  {item.pack_size} · Qty {item.quantity}
                </p>
              </div>
              <p className="text-sm font-bold text-ink-800">
                ₹{Number(item.line_total).toLocaleString('en-IN')}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Address */}
      {address && (
        <section className="bg-white border border-ink-100 rounded-2xl p-4 shadow-card">
          <h2 className="text-sm font-bold text-ink-900 mb-2">Delivery address</h2>
          <div className="flex items-start gap-2.5">
            <MapPin size={17} className="text-brand-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-ink-800">
                {address.label} · {address.recipient_name}
              </p>
              <p className="text-xs text-ink-600 mt-1 leading-relaxed">
                {address.line1}
                {address.line2 ? `, ${address.line2}` : ''}, {address.city},{' '}
                {address.state} - {address.postal_code}
              </p>
              <p className="text-xs text-ink-400 mt-1">{address.phone}</p>
            </div>
          </div>
        </section>
      )}

      {/* Payment Details & Multi-Payment Breakdown */}
      <section className="bg-white border border-ink-100 rounded-2xl p-4 shadow-card space-y-2">
        <h2 className="text-sm font-bold text-ink-900 mb-1">Payment Breakdown</h2>
        <div className="flex justify-between text-xs text-ink-500">
          <span>Subtotal</span>
          <span>₹{Number(order.subtotal).toLocaleString('en-IN')}</span>
        </div>
        {Number(order.discount) > 0 && (
          <div className="flex justify-between text-xs text-brand-600">
            <span>Discount</span>
            <span>- ₹{Number(order.discount).toLocaleString('en-IN')}</span>
          </div>
        )}
        {Number(order.cgst_amount) > 0 && (
          <div className="flex justify-between text-xs text-ink-500">
            <span>CGST</span>
            <span>₹{Number(order.cgst_amount).toLocaleString('en-IN')}</span>
          </div>
        )}
        {Number(order.sgst_amount) > 0 && (
          <div className="flex justify-between text-xs text-ink-500">
            <span>SGST</span>
            <span>₹{Number(order.sgst_amount).toLocaleString('en-IN')}</span>
          </div>
        )}
        <div className="flex justify-between text-xs text-ink-500">
          <span>Delivery fee</span>
          <span>₹{Number(order.delivery_fee).toLocaleString('en-IN')}</span>
        </div>

        <div className="border-t border-dashed border-ink-200 pt-2 flex justify-between">
          <span className="text-sm font-bold text-ink-800">Total Order Value</span>
          <span className="text-base font-extrabold text-ink-900">
            ₹{Number(order.total).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </span>
        </div>

        {paymentSummary.walletPaid > 0 && (
          <div className="flex justify-between text-xs text-emerald-600 font-semibold items-center pt-1">
            <span className="flex items-center gap-1.5"><Wallet size={13} /> Paid via Wallet</span>
            <span>- ₹{paymentSummary.walletPaid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
          </div>
        )}

        {paymentSummary.onlinePaid > 0 && (
          <div className="flex justify-between text-xs text-blue-600 font-semibold items-center">
            <span className="flex items-center gap-1.5"><CreditCard size={13} /> Paid Online (Razorpay)</span>
            <span>- ₹{paymentSummary.onlinePaid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
          </div>
        )}

        {paymentSummary.codPaid > 0 && (
          <div className="flex justify-between text-xs text-emerald-600 font-semibold items-center">
            <span className="flex items-center gap-1.5"><Banknote size={13} /> COD Settled</span>
            <span>- ₹{paymentSummary.codPaid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
          </div>
        )}

        {!paymentSummary.isFullyPaid && (
          <div className="flex justify-between text-xs text-amber-700 font-bold items-center pt-1 border-t border-ink-100">
            <span className="flex items-center gap-1.5"><Banknote size={13} /> Balance Due (COD)</span>
            <span>₹{paymentSummary.amountToCollect.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
          </div>
        )}
      </section>

      {canPrintBill && (
        <button
          disabled={isPrinting}
          onClick={() => void handlePrint()}
          className="w-full h-11 rounded-lg bg-blue-600 disabled:bg-blue-400 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-sm hover:bg-blue-700 transition-colors"
        >
          {isPrinting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Preparing Bill...
            </>
          ) : (
            <>
              <Printer size={18} /> Print / Save Bill (PDF)
            </>
          )}
        </button>
      )}
    </div>
  );
}
